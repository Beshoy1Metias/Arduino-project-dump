Note: These examples were originally designed for RPi, but should work on any supported Linux platform, with the proper pin configuration.

See http://tmrh20.github.io/RF24 for more information